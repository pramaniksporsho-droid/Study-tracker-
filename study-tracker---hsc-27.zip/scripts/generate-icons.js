import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function crc32(buf) {
  let table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c;
  }
  let crc = 0 ^ (-1);
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
  }
  return (crc ^ (-1)) >>> 0;
}

function makeChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const body = Buffer.concat([typeBuf, data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

function generateIcon(size, isMaskable = false) {
  // Raw scanlines: each line starts with 0x00 filter byte followed by size * 4 bytes (RGBA)
  const lineLength = 1 + size * 4;
  const rawData = Buffer.alloc(lineLength * size);

  const cx = size / 2;
  const cy = size / 2;
  const radius = size * (isMaskable ? 0.38 : 0.44);

  for (let y = 0; y < size; y++) {
    const lineOffset = y * lineLength;
    rawData[lineOffset] = 0; // Filter: None

    for (let x = 0; x < size; x++) {
      const pxOffset = lineOffset + 1 + x * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Background color: #1b1f3b (27, 31, 59)
      let r = 27;
      let g = 31;
      let b = 59;
      let a = 255;

      // Outer gold circle / owl head representation
      if (dist < radius) {
        // Gold / Amber accent: #b8892b (184, 137, 43) or warm glow #f59e0b
        r = 217;
        g = 153;
        b = 38;

        // Inner belly / face circle
        const eyeY = cy - radius * 0.15;
        const leftEyeX = cx - radius * 0.35;
        const rightEyeX = cx + radius * 0.35;
        const eyeDistL = Math.hypot(x - leftEyeX, y - eyeY);
        const eyeDistR = Math.hypot(x - rightEyeX, y - eyeY);

        // Eyes
        if (eyeDistL < radius * 0.28 || eyeDistR < radius * 0.28) {
          // White eye base
          r = 255;
          g = 255;
          b = 255;
          // Pupil
          if (eyeDistL < radius * 0.14 || eyeDistR < radius * 0.14) {
            r = 27;
            g = 31;
            b = 59;
          }
        } else if (y > cy && dist < radius * 0.65) {
          // White belly
          r = 245;
          g = 245;
          b = 250;
        } else if (Math.abs(dx) < radius * 0.2 && y > eyeY && y < cy + radius * 0.25) {
          // Orange beak
          r = 245;
          g = 158;
          b = 11;
        }
      }

      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type: RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const ihdrChunk = makeChunk('IHDR', ihdr);
  const compressed = zlib.deflateSync(rawData);
  const idatChunk = makeChunk('IDAT', compressed);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([sig, ihdrChunk, idatChunk, iendChunk]);
}

const publicDir = path.resolve(process.cwd(), 'public');
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), generateIcon(192));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), generateIcon(512));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), generateIcon(512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), generateIcon(180));
console.log('Successfully generated PWA PNG icons!');
