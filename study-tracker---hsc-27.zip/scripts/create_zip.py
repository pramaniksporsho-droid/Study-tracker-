import os
import zipfile

def create_index_zip():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    target_zip = os.path.join(base_dir, 'public', 'index.zip')
    os.makedirs(os.path.join(base_dir, 'public'), exist_ok=True)
    
    include_files = [
        'index.html',
        'server.ts',
        'package.json',
        'tsconfig.json',
        'vite.config.ts',
        'metadata.json'
    ]
    
    include_dirs = [
        'src',
        'public'
    ]
    
    with zipfile.ZipFile(target_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        standalone_src = os.path.join(base_dir, 'public', 'assets', 'aistudio', 'index-4_964ee8a0.html')
        if os.path.exists(standalone_src):
            zf.write(standalone_src, arcname='index-standalone.html')
            
        for f in include_files:
            full_path = os.path.join(base_dir, f)
            if os.path.exists(full_path):
                zf.write(full_path, arcname=f)
                
        for d in include_dirs:
            full_dir = os.path.join(base_dir, d)
            if os.path.exists(full_dir):
                for root, _, files in os.walk(full_dir):
                    for file in files:
                        if file == 'index.zip':
                            continue
                        file_path = os.path.join(root, file)
                        rel_path = os.path.relpath(file_path, base_dir)
                        zf.write(file_path, arcname=rel_path)

        readme_content = """# Study Tracker - HSC 27

Minimal Study Tracker for HSC 27 with background notifications, chapter progress tracking, mascots, and offline PWA support.

## How to Run:
1. npm install
2. npm run dev
3. Open http://localhost:3000

## Files Included:
- index-standalone.html: Single-file offline version
- src/: Full React 19 + TypeScript + Tailwind source code
- server.ts: Web Push server & background scheduled notification runner
- public/: PWA icons, manifest.json, sw.js (Service Worker)
"""
        zf.writestr('README.md', readme_content)

    print(f"Successfully generated {target_zip} (size: {os.path.getsize(target_zip)} bytes)")

if __name__ == '__main__':
    create_index_zip()
