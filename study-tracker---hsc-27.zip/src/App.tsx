import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { ViewType, UserPreferences, StudyMaterial } from './types';
import { SUBJECTS, MOTIVATIONAL_QUOTES } from './data/syllabus';
import { soundEffects } from './utils/audio';
import {
  registerServiceWorker,
  checkPushStatus,
  subscribeToPushNotifications
} from './utils/pushManager';
import { Navbar } from './components/Navbar';
import { HomeView } from './components/HomeView';
import { SubjectView } from './components/SubjectView';
import { ProgressView } from './components/ProgressView';
import { MaterialsView } from './components/MaterialsView';
import { SettingsView } from './components/SettingsView';
import { CelebrationModal } from './components/CelebrationModal';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';

const DEFAULT_PREFS: UserPreferences = {
  name: '',
  mascot: 'owl',
  theme: '',
  mute: false,
  notificationsEnabled: false,
  intervalMinutes: 60,
  nudgeStyle: 'mixed',
  quietHoursEnabled: true,
  quietHoursStart: 23,
  quietHoursEnd: 7
};

export default function App() {
  // Load preferences
  const [userPrefs, setUserPrefs] = useState<UserPreferences>(() => {
    try {
      const saved = localStorage.getItem('pf2');
      if (saved) {
        return { ...DEFAULT_PREFS, ...JSON.parse(saved) };
      }
    } catch (e) {}
    return DEFAULT_PREFS;
  });

  // Load progress
  const [progress, setProgress] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('st2');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {};
  });

  // Load study materials
  const [materials, setMaterials] = useState<StudyMaterial[]>(() => {
    try {
      const saved = localStorage.getItem('mt2');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [];
  });

  const [currentView, setCurrentView] = useState<ViewType>(() => {
    return userPrefs.name ? 'home' : 'set';
  });

  const [selectedSubjectIndex, setSelectedSubjectIndex] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastTimer, setToastTimer] = useState<any>(null);
  const [isPushActive, setIsPushActive] = useState<boolean>(false);
  const [celebrationData, setCelebrationData] = useState<{
    subjectTitle: string;
    chapterNum: number;
  } | null>(null);

  // Motivational quote for this session
  const randomQuote = useMemo(() => {
    const idx = Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length);
    return MOTIVATIONAL_QUOTES[idx];
  }, []);

  const showToast = useCallback((msg: string) => {
    if (toastTimer) clearTimeout(toastTimer);
    setToastMessage(msg);
    const t = setTimeout(() => {
      setToastMessage(null);
    }, 4000);
    setToastTimer(t);
  }, [toastTimer]);

  // Sync theme
  useEffect(() => {
    if (userPrefs.theme) {
      document.documentElement.dataset.theme = userPrefs.theme;
    } else {
      delete document.documentElement.dataset.theme;
    }
  }, [userPrefs.theme]);

  // Register Service Worker and check push status on startup
  useEffect(() => {
    registerServiceWorker().then(() => {
      checkPushStatus().then((status) => {
        setIsPushActive(status.isSubscribed);
      });
    });
  }, []);

  // Update preferences helper
  const handleUpdatePrefs = (newPrefs: Partial<UserPreferences>) => {
    setUserPrefs((prev) => {
      const updated = { ...prev, ...newPrefs };
      try {
        localStorage.setItem('pf2', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  // Calculate stats for a given subject
  const getSubjectStats = useCallback(
    (subjIndex: number) => {
      const subj = SUBJECTS[subjIndex];
      let totalChapters = 0;
      subj.groups.forEach((g) => {
        totalChapters += g[1].split('|').length;
      });

      let finished = 0;
      let totalStepsDone = 0;
      const totalStepsPossible = totalChapters * subj.steps.length;

      for (let c = 1; c <= totalChapters; c++) {
        let stepsDone = 0;
        subj.steps.forEach((_, stepIdx) => {
          if (progress[`${subjIndex}.${c}.${stepIdx}`]) {
            stepsDone++;
          }
        });
        totalStepsDone += stepsDone;
        if (stepsDone === subj.steps.length) {
          finished++;
        }
      }

      const percent =
        totalStepsPossible > 0
          ? Math.round((totalStepsDone / totalStepsPossible) * 100)
          : 0;

      return { finished, total: totalChapters, percent };
    },
    [progress]
  );

  // Toggle chapter step
  const handleToggleStep = (subjIdx: number, chapNum: number, stepIdx: number) => {
    const key = `${subjIdx}.${chapNum}.${stepIdx}`;
    const wasDone = Boolean(progress[key]);

    const newProgress = { ...progress };
    if (wasDone) {
      delete newProgress[key];
      soundEffects.tap(userPrefs.mute);
    } else {
      newProgress[key] = 1;

      // Check if all steps in this chapter are now complete
      const subj = SUBJECTS[subjIdx];
      const isNowComplete = subj.steps.every((_, sIdx) =>
        sIdx === stepIdx ? true : Boolean(newProgress[`${subjIdx}.${chapNum}.${sIdx}`])
      );

      if (isNowComplete) {
        soundEffects.cheer(userPrefs.mute);
        setCelebrationData({
          subjectTitle: subj.title,
          chapterNum: chapNum
        });
        if ('vibrate' in navigator) {
          try {
            navigator.vibrate([80, 40, 80]);
          } catch (e) {}
        }
      } else {
        soundEffects.tick(userPrefs.mute);
      }
    }

    setProgress(newProgress);
    try {
      localStorage.setItem('st2', JSON.stringify(newProgress));
    } catch (e) {}
  };

  // Add Material
  const handleAddMaterial = (mat: StudyMaterial) => {
    const updated = [...materials, mat];
    setMaterials(updated);
    try {
      localStorage.setItem('mt2', JSON.stringify(updated));
    } catch (e) {}
    showToast('Resource link added ✨');
  };

  // Delete Material
  const handleDeleteMaterial = (index: number) => {
    const updated = materials.filter((_, idx) => idx !== index);
    setMaterials(updated);
    try {
      localStorage.setItem('mt2', JSON.stringify(updated));
    } catch (e) {}
    showToast('Resource removed');
  };

  // Export JSON backup
  const handleBackupExport = () => {
    try {
      const data = {
        app: 'Study Tracker',
        version: 2,
        exportedAt: new Date().toISOString(),
        progress,
        preferences: userPrefs,
        materials
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: 'application/json'
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `study-tracker-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      showToast('Backup file downloaded ✨');
    } catch (e) {
      showToast('Could not export backup. Please try again.');
    }
  };

  // Import JSON backup
  const handleBackupImport = async (file: File) => {
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!data || !data.progress || !data.preferences) {
        throw new Error('Invalid backup file');
      }

      if (
        !window.confirm(
          'Import this backup? Your current progress, settings, and materials will be updated.'
        )
      ) {
        return;
      }

      const importedProgress = data.progress;
      const importedPrefs: UserPreferences = {
        ...DEFAULT_PREFS,
        ...data.preferences
      };
      const importedMaterials = Array.isArray(data.materials) ? data.materials : [];

      setProgress(importedProgress);
      setUserPrefs(importedPrefs);
      setMaterials(importedMaterials);

      localStorage.setItem('st2', JSON.stringify(importedProgress));
      localStorage.setItem('pf2', JSON.stringify(importedPrefs));
      localStorage.setItem('mt2', JSON.stringify(importedMaterials));

      if (importedPrefs.theme) {
        document.documentElement.dataset.theme = importedPrefs.theme;
      } else {
        delete document.documentElement.dataset.theme;
      }

      showToast('Backup restored successfully ✨');
    } catch (e) {
      showToast('The backup file is invalid or damaged.');
    }
  };

  // Handle navigation
  const handleNavigate = (view: ViewType) => {
    soundEffects.tap(userPrefs.mute);
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    checkPushStatus().then((s) => setIsPushActive(s.isSubscribed));
  };

  const handleSelectSubject = (index: number) => {
    soundEffects.tap(userPrefs.mute);
    setSelectedSubjectIndex(index);
    setCurrentView('subj');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="max-w-[720px] mx-auto px-3.5 pt-[calc(env(safe-area-inset-top,0px)+14px)] pb-28 min-h-screen">
      {/* Offline Status indicator */}
      <OfflineIndicator />

      {/* Toast popup */}
      {toastMessage && (
        <div className="fixed left-3 right-3 top-[calc(env(safe-area-inset-top,0px)+12px)] max-w-[500px] mx-auto z-50 bg-[#1b1f3b] text-[#f3e6c4] border border-[var(--ac)] p-3.5 rounded-2xl shadow-xl text-xs sm:text-sm font-medium flex items-center justify-between">
          <span>{toastMessage}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="text-[var(--ac)] hover:text-white ml-2 text-xs font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {/* PWA Install prompt banner */}
      <div className="mb-3">
        <PWAInstallButton />
      </div>

      {/* Views */}
      <main>
        {currentView === 'home' && (
          <HomeView
            userPrefs={userPrefs}
            subjects={SUBJECTS}
            getSubjectStats={getSubjectStats}
            onSelectSubject={handleSelectSubject}
            randomQuote={randomQuote}
            isPushActive={isPushActive}
            onOpenNotificationSettings={() => handleNavigate('set')}
          />
        )}

        {currentView === 'subj' && (
          <SubjectView
            subject={SUBJECTS[selectedSubjectIndex]}
            subjectIndex={selectedSubjectIndex}
            progress={progress}
            onToggleStep={handleToggleStep}
            onBack={() => handleNavigate('home')}
          />
        )}

        {currentView === 'prog' && (
          <ProgressView
            subjects={SUBJECTS}
            getSubjectStats={getSubjectStats}
          />
        )}

        {currentView === 'mat' && (
          <MaterialsView
            subjects={SUBJECTS}
            materials={materials}
            onAddMaterial={handleAddMaterial}
            onDeleteMaterial={handleDeleteMaterial}
          />
        )}

        {currentView === 'set' && (
          <SettingsView
            userPrefs={userPrefs}
            onUpdatePrefs={handleUpdatePrefs}
            onBackupExport={handleBackupExport}
            onBackupImport={handleBackupImport}
            onToast={showToast}
          />
        )}
      </main>

      {/* Chapter completion celebration modal */}
      {celebrationData && (
        <CelebrationModal
          subjectTitle={celebrationData.subjectTitle}
          chapterNum={celebrationData.chapterNum}
          mascotId={userPrefs.mascot}
          onClose={() => setCelebrationData(null)}
        />
      )}

      {/* Bottom Navbar */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        notificationsActive={isPushActive}
      />
    </div>
  );
}
