export interface Chapter {
  name: string;
  group: string;
}

export interface SubjectData {
  title: string;
  groups: [string, string][]; // [groupName, "chap1|chap2|chap3"]
  steps: string[];
  color: string;
}

export interface UserPreferences {
  name: string;
  mascot: string;
  theme: 'light' | 'dark' | '';
  mute: boolean;
  // Push Notification settings
  notificationsEnabled: boolean;
  intervalMinutes: number;
  nudgeStyle: 'angry' | 'motivational' | 'mixed';
  quietHoursEnabled: boolean;
  quietHoursStart: number;
  quietHoursEnd: number;
}

export interface StudyMaterial {
  subjectIndex: number;
  title: string;
  url: string;
}

export interface MascotInfo {
  id: string;
  name: string;
  emoji?: string;
}

export type ViewType = 'home' | 'subj' | 'prog' | 'mat' | 'set';
