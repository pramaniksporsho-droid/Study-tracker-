let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  try {
    if (!audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        audioCtx = new AudioCtxClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  } catch (e) {
    return null;
  }
}

function playTone(
  freq: number,
  timeOffset: number,
  duration: number,
  type: OscillatorType = 'sine',
  volume = 0.15,
  isMuted = false
) {
  if (isMuted) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const startTime = ctx.currentTime + timeOffset;

    osc.type = type;
    osc.frequency.value = freq;

    gain.gain.setValueAtTime(0, startTime);
    gain.gain.linearRampToValueAtTime(volume, startTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + duration + 0.02);
  } catch (e) {
    // Audio errors fail gracefully
  }
}

export const soundEffects = {
  tap: (isMuted = false) => {
    playTone(660, 0, 0.07, 'triangle', 0.1, isMuted);
  },
  tick: (isMuted = false) => {
    playTone(880, 0, 0.12, 'sine', 0.15, isMuted);
    playTone(1320, 0.08, 0.2, 'sine', 0.15, isMuted);
  },
  lock: (isMuted = false) => {
    playTone(300, 0, 0.12, 'square', 0.07, isMuted);
  },
  angry: (isMuted = false) => {
    playTone(220, 0, 0.2, 'sawtooth', 0.12, isMuted);
    playTone(165, 0.22, 0.35, 'sawtooth', 0.12, isMuted);
  },
  cheer: (isMuted = false) => {
    [523, 659, 784, 1047, 1319].forEach((freq, idx) => {
      playTone(freq, idx * 0.11, 0.3, 'triangle', 0.18, isMuted);
    });
    playTone(1568, 0.6, 0.5, 'sine', 0.15, isMuted);
  }
};
