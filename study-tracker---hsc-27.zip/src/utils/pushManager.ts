import { UserPreferences } from '../types';

export interface PushStatus {
  isSupported: boolean;
  permission: NotificationPermission;
  isSubscribed: boolean;
  endpoint?: string;
  error?: string;
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const buffer = new ArrayBuffer(rawData.length);
  const outputArray = new Uint8Array(buffer);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
    return null;
  }
  try {
    const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
    await navigator.serviceWorker.ready;
    return reg;
  } catch (err) {
    console.error('Service worker registration error:', err);
    return null;
  }
}

export async function checkPushStatus(): Promise<PushStatus> {
  if (
    typeof window === 'undefined' ||
    !('serviceWorker' in navigator) ||
    !('PushManager' in window) ||
    !('Notification' in window)
  ) {
    return {
      isSupported: false,
      permission: 'default',
      isSubscribed: false,
      error: 'Push notifications are not supported in this browser/device mode.'
    };
  }

  const permission = Notification.permission;
  try {
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.getSubscription();
    return {
      isSupported: true,
      permission,
      isSubscribed: Boolean(sub),
      endpoint: sub ? sub.endpoint : undefined
    };
  } catch (e: any) {
    return {
      isSupported: true,
      permission,
      isSubscribed: false,
      error: e?.message
    };
  }
}

export async function subscribeToPushNotifications(
  userPrefs: UserPreferences
): Promise<{ success: boolean; error?: string }> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return { success: false, error: 'Notifications are not supported in this browser.' };
  }

  // 1. Request browser permission
  let permission = Notification.permission;
  if (permission === 'default') {
    permission = await Notification.requestPermission();
  }

  if (permission !== 'granted') {
    return {
      success: false,
      error: permission === 'denied'
        ? 'Notifications are blocked. Please enable notifications in your browser or phone site settings.'
        : 'Notification permission was dismissed.'
    };
  }

  try {
    // 2. Ensure Service Worker is registered
    const reg = await registerServiceWorker();
    if (!reg) {
      return { success: false, error: 'Failed to initialize background service worker.' };
    }

    // 3. Fetch VAPID Public Key from server
    const keyRes = await fetch('/api/push/public-key');
    if (!keyRes.ok) {
      throw new Error('Failed to retrieve push encryption key from server');
    }
    const { publicKey } = await keyRes.json();
    if (!publicKey) {
      throw new Error('VAPID public key not found on server');
    }

    // 4. Check for existing subscription or create new
    let sub = await reg.pushManager.getSubscription();
    if (!sub) {
      const convertedKey = urlBase64ToUint8Array(publicKey);
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: convertedKey as any
      });
    }

    // 5. Send subscription + user preferences to backend
    const subPayload = JSON.parse(JSON.stringify(sub));
    const res = await fetch('/api/push/subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subscription: subPayload,
        userName: userPrefs.name,
        intervalMinutes: userPrefs.intervalMinutes || 60,
        nudgeStyle: userPrefs.nudgeStyle || 'mixed',
        quietHoursEnabled: userPrefs.quietHoursEnabled,
        quietHoursStart: userPrefs.quietHoursStart,
        quietHoursEnd: userPrefs.quietHoursEnd
      })
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'Failed to save subscription on server');
    }

    return { success: true };
  } catch (err: any) {
    console.error('Subscription error:', err);
    return { success: false, error: err.message || 'Error subscribing to background notifications' };
  }
}

export async function unsubscribeFromPushNotifications(): Promise<{ success: boolean; error?: string }> {
  try {
    if (!('serviceWorker' in navigator)) return { success: true };
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.getSubscription();
    if (sub) {
      const endpoint = sub.endpoint;
      await sub.unsubscribe();
      await fetch('/api/push/unsubscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpoint })
      }).catch(() => {});
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message };
  }
}

export async function sendTestPushNotification(
  delaySeconds = 0,
  customMessage?: string,
  userPrefs?: Partial<UserPreferences>
): Promise<{ success: boolean; message?: string; scheduled?: boolean; error?: string }> {
  try {
    const reg = await registerServiceWorker();
    if (!reg) throw new Error('Service worker not registered');
    let sub = await reg.pushManager.getSubscription();

    // If not subscribed yet, try to auto-subscribe
    if (!sub) {
      const keyRes = await fetch('/api/push/public-key');
      const { publicKey } = await keyRes.json();
      if (!publicKey) throw new Error('Could not get push public key');
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicKey) as any
      });
    }

    const res = await fetch('/api/push/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subscription: JSON.parse(JSON.stringify(sub)),
        delaySeconds,
        customMessage,
        userName: userPrefs?.name,
        nudgeStyle: userPrefs?.nudgeStyle || 'angry'
      })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to send test push');
    return {
      success: true,
      message: data.message,
      scheduled: data.scheduled
    };
  } catch (e: any) {
    return { success: false, error: e?.message || 'Failed to send push test' };
  }
}
