import { SubjectData, MascotInfo } from '../types';

export const LANGUAGE_STEPS = ["Book Read", "Writing Practice", "MCQ Prep", "Class"];
export const SCIENCE_MATH_STEPS = ["MCQ Prep", "Math Solving", "One Shot CQ", "One Shot MCQ"];
export const BIOLOGY_STEPS = ["Book", "Revision", "CQ Solve", "MCQ Solve"];

export const SUBJECT_COLORS = [
  "#e11d48", // Bangla - Crimson Rose
  "#2563eb", // English - Royal Blue
  "#7c3aed", // ICT - Violet
  "#ea580c", // Physics - Amber Orange
  "#0d9488", // Chemistry - Teal
  "#c026d3", // Higher Math - Purple Fuchsia
  "#16a34a"  // Biology - Emerald Green
];

export const RAW_SUBJECTS: [string, [string, string][]][] = [
  [
    "বাংলা",
    [
      ["১ম পত্র — গদ্য", "বাঙ্গালার নব্য লেখকদিগের প্রতি নিবেদন|অপরিচিতা|সাহিত্যে খেলা|বিলাসী|অর্ধাঙ্গী|যৌবনের গান|জীবন ও বৃক্ষ|গন্তব্য কাবুল|মাসি-পিসি|কপিলদাস মুর্মুর শেষ কাজ|রেইনকোট|নেকলেস"],
      ["১ম পত্র — কবিতা", "ঋতু-বর্ণন|বিভীষণের প্রতি মেঘনাদ|সোনার তরী|বিদ্রোহী|সুচেতনা|প্রতিদান|তাহারেই পড়ে মনে|পদ্মা|ফেব্রুয়ারি ১৯৬৯|আঠার বছর বয়স|আমি কিংবদন্তির কথা বলছি|প্রত্যাবর্তনের লজ্জা"],
      ["১ম পত্র — সহপাঠ", "লালসালু (উপন্যাস)|সিরাজউদ্দৌলা (নাটক)"],
      ["২য় পত্র — মানবণ্টন", "উচ্চারণের নিয়ম|বাংলা বানানের নিয়ম|বাক্য শুদ্ধিকরণ|এক কথায় প্রকাশ|বাগধারা ও প্রবাদ-প্রবচন|পারিভাষিক শব্দ|সমার্থক শব্দ|বিপরীতার্থক শব্দ|অনুবাদ|সারাংশ ও সারমর্ম|ভাব-সম্প্রসারণ|প্রতিবেদন রচনা|অনুচ্ছেদ রচনা|পত্র লিখন (আবেদনপত্র/ব্যক্তিগত পত্র)|প্রবন্ধ রচনা"]
    ]
  ],
  [
    "English",
    [
      ["১ম পত্র", "Unit 1: Education and Life|Unit 2: Art and Craft|Unit 3: Myths and Literature|Unit 4: History|Unit 5: Human Rights|Unit 6: Dreams|Unit 7: Youthful Achievers|Unit 8: Relationships|Unit 9: Adolescence|Unit 10: Lifestyle|Unit 11: Peace and Conflict|Unit 12: Environment and Nature"],
      ["২য় পত্র — মানবণ্টন", "Gap Filling without Clues|Cloze Test with Clues|Cloze Test without Clues|Rearranging|Completing Sentences|Right Form of Verbs|Preposition|Use of Articles|Transformation of Sentences|Narration (Direct-Indirect Speech)|Paragraph Writing|Formal Letter / Email Writing|Report Writing|Graph/Chart Description|CV Writing with Cover Letter|Summary Writing|Composition / Essay Writing"]
    ]
  ],
  [
    "ICT",
    [
      ["তথ্য ও যোগাযোগ প্রযুক্তি", "বিশ্ব ও বাংলাদেশ প্রেক্ষিত|কমিউনিকেশন সিস্টেমস ও নেটওয়ার্কিং|সংখ্যা পদ্ধতি ও ডিজিটাল ডিভাইস|ওয়েব ডিজাইন পরিচিতি এবং এইচটিএমএল|প্রোগ্রামিং ভাষা|ডেটাবেজ ম্যানেজমেন্ট সিস্টেম"]
    ]
  ],
  [
    "Physics",
    [
      ["১ম পত্র", "ভৌত জগৎ ও পরিমাপ|ভেক্টর|গতিবিদ্যা|নিউটনিয়ান বলবিদ্যা|কাজ, শক্তি ও ক্ষমতা|মহাকর্ষ ও অভিকর্ষ|পদার্থের গাঠনিক ধর্ম|পর্যাবৃত্ত গতি|তরঙ্গ|আদর্শ গ্যাস ও গ্যাসের গতিতত্ত্ব"],
      ["২য় পত্র", "তাপগতিবিদ্যা|স্থির তড়িৎ|চল তড়িৎ|তড়িৎ প্রবাহের চৌম্বক ক্রিয়া ও চুম্বকত্ব|তড়িৎচৌম্বকীয় আবেশ ও দিক পরিবর্তী প্রবাহ|জ্যামিতিক আলোকবিজ্ঞান|ভৌত আলোকবিজ্ঞান|আধুনিক পদার্থবিজ্ঞানের সূচনা|পরমাণুর মডেল ও নিউক্লিয়ার পদার্থবিজ্ঞান|সেমিকন্ডাক্টর ও ইলেকট্রনিক্স|জ্যোতির্বিজ্ঞান"]
    ]
  ],
  [
    "Chemistry",
    [
      ["১ম পত্র", "ল্যাবরেটরির নিরাপদ ব্যবহার|গুণগত রসায়ন|মৌলের পর্যায়বৃত্ত ধর্ম ও রাসায়নিক বন্ধন|রাসায়নিক পরিবর্তন|কর্মমুখী রসায়ন"],
      ["২য় পত্র", "পরিবেশ রসায়ন|জৈব রসায়ন|পরিমাণগত রসায়ন|তড়িৎ রসায়ন|অর্থনৈতিক রসায়ন"]
    ]
  ],
  [
    "Higher Math",
    [
      ["১ম পত্র", "ম্যাট্রিক্স ও নির্ণায়ক|ভেক্টর|সরলরেখা|বৃত্ত|বিন্যাস ও সমাবেশ|ত্রিকোণমিতিক অনুপাত|সংযুক্ত কোণের ত্রিকোণমিতিক অনুপাত|ফাংশন ও ফাংশনের লেখচিত্র|অন্তরীকরণ (ক্যালকুলাস)|যোগজীকরণ (ক্যালকুলাস)"],
      ["২য় পত্র", "বাস্তব সংখ্যা ও অসমতা|যোগাশ্রয়ী প্রোগ্রাম|জটিল সংখ্যা|বহুপদী ও বহুপদী সমীকরণ|দ্বিপদী বিস্তৃতি|কণিক|বিপরীত ত্রিকোণমিতিক ফাংশন ও ত্রিকোণমিতিক সমীকরণ|স্থিতিবিদ্যা|সমতলে বস্তুকণার গতি|বিস্তার পরিমাপ ও সম্ভাবনা"]
    ]
  ],
  [
    "Biology",
    [
      ["১ম পত্র — উদ্ভিদবিজ্ঞান", "কোষ ও এর গঠন|কোষ বিভাজন|কোষ রসায়ন|অণুজীব|শৈবাল ও ছত্রাক|ব্রায়োফাইটা ও টেরিডোফাইটা|নগ্নবীজী ও আবৃতবীজী উদ্ভিদ|টিস্যু ও টিস্যুতন্ত্র|উদ্ভিদ শরীরতত্ত্ব|উদ্ভিদ প্রজনন|জীবপ্রযুক্তি|জীবের পরিবেশ, বিস্তার ও সংরক্ষণ"],
      ["২য় পত্র — প্রাণিবিজ্ঞান", "প্রাণীর বিভিন্নতা ও শ্রেণিবিন্যাস|প্রাণীর পরিচিতি|মানব শরীরতত্ত্ব: পরিপাক ও শোষণ|মানব শরীরতত্ত্ব: রক্ত ও সংবহন|মানব শরীরতত্ত্ব: শ্বসন ও শ্বাসক্রিয়া|মানব শরীরতত্ত্ব: বর্জ্য ও নিষ্কাশন|মানব শরীরতত্ত্ব: চলন ও অঙ্গচালনা|মানব শরীরতত্ত্ব: সমন্বয় ও নিয়ন্ত্রণ|মানব জীবনের ধারাবাহিকতা|মানবদেহের প্রতিরক্ষা|জিন তত্ত্ব ও বিবর্তন|প্রাণীর আচরণ"]
    ]
  ]
];

export const SUBJECTS: SubjectData[] = RAW_SUBJECTS.map((raw, i) => {
  let steps = LANGUAGE_STEPS;
  if (i === 0 || i === 1) steps = LANGUAGE_STEPS;
  else if (i === 6) steps = BIOLOGY_STEPS;
  else steps = SCIENCE_MATH_STEPS;

  return {
    title: raw[0],
    groups: raw[1],
    steps,
    color: SUBJECT_COLORS[i]
  };
});

export const MASCOTS: MascotInfo[] = [
  { id: "owl", name: "Professor Owl" },
  { id: "robot", name: "Robo", emoji: "🤖" },
  { id: "astro", name: "Astro", emoji: "🧑‍🚀" },
  { id: "ninja", name: "Ninja", emoji: "🥷" },
  { id: "wizard", name: "Wizard", emoji: "🧙" },
  { id: "dragon", name: "Dragon", emoji: "🐲" },
  { id: "unicorn", name: "Unicorn", emoji: "🦄" },
  { id: "dino", name: "Dino", emoji: "🦖" },
  { id: "penguin", name: "Penguin", emoji: "🐧" }
];

export const MOTIVATIONAL_QUOTES = [
  "Consistency defeats talent every time.",
  "Show up today. That is the whole job.",
  "Small steps, every single day.",
  "One chapter closer than yesterday.",
  "Discipline beats motivation.",
  "Done is better than perfect.",
  "Rest if you must. Never quit.",
  "Your future self is counting on today.",
  "Study now. Celebrate later.",
  "Hard work stays quiet until results speak.",
  "Progress, not perfection.",
  "Every tick is a promise kept.",
  "Start before you feel ready.",
  "Focus on today, not on everyone else.",
  "Dreams need daily effort.",
  "A little every day becomes a lot.",
  "Tired is temporary. Regret is not.",
  "Be the student your younger self prayed for.",
  "Don’t stop when you’re tired. Stop when you’re done.",
  "Success is the sum of small efforts repeated.",
  "Your only competition is yesterday’s you.",
  "Turn off the phone. Turn on the focus.",
  "Hard now, easy later.",
  "You are one chapter away from a better day."
];

export const ANGRY_NUDGES = [
  "কিরে তোর পড়ার ইচ্ছা নাই? 😡",
  "তুই কি ফেল করবি পরীক্ষায়? 😠🤬",
  "লজ্জা আছে? 😤😡",
  "বাপ-মাকে লজ্জায় ফেলিস না। 😡😠",
  "পড়তেসিস তুই? 🤨😠"
];

export const CELEBRATION_MESSAGES = [
  "দারুণ! আরেকটা চ্যাপ্টার শেষ! 🔥",
  "শাবাশ! এভাবেই চালিয়ে যা! 💪",
  "তুই পারবি, আমি জানি! 🌟",
  "একটু একটু করে তুই টপার হচ্ছিস! 🏆",
  "বাপ-মা তোকে নিয়ে গর্ব করবে! ❤️",
  "থামিস না, সামনে আরও জয় অপেক্ষা করছে! 🚀"
];

export const BUILDER_NAME = "Sporsho Pramanik";
export const WHATSAPP_LINK = "https://wa.me/8801853152415";
