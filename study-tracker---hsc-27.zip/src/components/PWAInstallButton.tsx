import React, { useState } from 'react';
import { usePWAInstall } from './usePWAInstall';
import { Download, Smartphone, X } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-3 rounded-2xl flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2.5">
          <Download className="w-5 h-5 shrink-0" />
          <div className="text-xs">
            <span className="font-bold block">Install App on Your Phone</span>
            <span className="text-blue-100 text-[11px]">Enables offline mode &amp; home screen launch</span>
          </div>
        </div>
        <button
          onClick={install}
          className="bg-white text-blue-700 font-bold text-xs px-3 py-1.5 rounded-xl hover:bg-blue-50 transition shadow-xs shrink-0"
        >
          Install
        </button>
      </div>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <div className="bg-[var(--card)] border border-[var(--bd)] p-3 rounded-2xl flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-5 h-5 text-[var(--ac)] shrink-0" />
            <div className="text-xs">
              <span className="font-bold block text-[var(--tx)]">Add to iPhone / iPad</span>
              <span className="text-[var(--mu)] text-[11px]">Install to home screen for full Web Push</span>
            </div>
          </div>
          <button
            onClick={() => setShowIOSGuide(true)}
            className="border border-[var(--ac)] text-[var(--ac)] font-bold text-xs px-3 py-1.5 rounded-xl hover:bg-[var(--ac)]/10 transition shrink-0"
          >
            How to Install
          </button>
        </div>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
            <div className="w-full max-w-sm rounded-2xl bg-[var(--card)] border border-[var(--bd)] p-5 shadow-2xl space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-[var(--tx)]">Install on iPhone / iPad</h3>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 text-[var(--mu)] hover:text-[var(--tx)]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="text-xs text-[var(--mu)] space-y-2">
                <p>
                  1. Tap the <b>Share</b> button <span className="text-blue-500 font-bold">⎋</span> in your Safari toolbar.
                </p>
                <p>
                  2. Scroll down and tap <b>Add to Home Screen</b>.
                </p>
                <p>
                  3. Launch from your home screen. Web push notifications will work seamlessly!
                </p>
              </div>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full py-2.5 rounded-xl bg-[var(--ac)] text-white font-bold text-xs hover:brightness-110 transition"
              >
                Got it
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
