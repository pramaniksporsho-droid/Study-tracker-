import React from 'react';
import { SubjectData } from '../types';

interface ProgressViewProps {
  subjects: SubjectData[];
  getSubjectStats: (subjectIndex: number) => { finished: number; total: number; percent: number };
}

export const ProgressView: React.FC<ProgressViewProps> = ({ subjects, getSubjectStats }) => {
  let totalStepsCompleted = 0;
  let totalStepsPossible = 0;
  let totalChaptersFinished = 0;
  let totalChaptersCount = 0;

  const subjectStatsList = subjects.map((subj, idx) => {
    const stats = getSubjectStats(idx);
    totalChaptersFinished += stats.finished;
    totalChaptersCount += stats.total;

    const maxSteps = stats.total * subj.steps.length;
    const completedSteps = Math.round((stats.percent / 100) * maxSteps);
    totalStepsCompleted += completedSteps;
    totalStepsPossible += maxSteps;

    return {
      subject: subj,
      stats
    };
  });

  const overallPercent = totalStepsPossible > 0 ? Math.round((totalStepsCompleted / totalStepsPossible) * 100) : 0;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <div className="text-xs uppercase tracking-wider font-bold text-[var(--mu)]">Overall</div>
        <h1 className="font-serif text-2xl font-bold">Progress</h1>
      </div>

      {/* Circular Progress Ring */}
      <div className="flex flex-col items-center justify-center p-4 bg-[var(--card)] border border-[var(--bd)] rounded-2xl shadow-xs">
        <div
          className="relative w-36 h-36 rounded-full flex items-center justify-center transition-all duration-700 shadow-inner"
          style={{
            background: `conic-gradient(var(--ac) ${overallPercent * 3.6}deg, var(--bd) 0deg)`
          }}
        >
          {/* Inner cutout */}
          <div className="absolute inset-3 rounded-full bg-[var(--bg)] flex flex-col items-center justify-center shadow-xs">
            <span className="font-serif text-3xl font-bold text-[var(--tx)]">{overallPercent}%</span>
            <span className="text-[10px] uppercase font-bold tracking-wider text-[var(--mu)]">Completed</span>
          </div>
        </div>

        <div className="mt-4 text-xs font-medium text-[var(--mu)] text-center">
          {totalChaptersFinished} of {totalChaptersCount} chapters fully locked
        </div>
      </div>

      {/* By Subject Section */}
      <div className="space-y-3">
        <div className="text-xs uppercase tracking-wider font-bold text-[var(--mu)]">
          By Subject
        </div>

        <div className="bg-[var(--card)] border border-[var(--bd)] rounded-2xl p-4 space-y-4 shadow-xs">
          {subjectStatsList.map(({ subject, stats }) => (
            <div key={subject.title} className="space-y-1.5">
              <div className="flex items-center justify-between text-xs sm:text-sm font-semibold">
                <span className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full inline-block"
                    style={{ backgroundColor: subject.color }}
                  />
                  <span>{subject.title}</span>
                </span>
                <span className="text-[var(--mu)]">
                  {stats.finished}/{stats.total} chapters · <b style={{ color: subject.color }}>{stats.percent}%</b>
                </span>
              </div>
              <div className="w-full h-2 bg-[var(--bd)] rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-300"
                  style={{ width: `${stats.percent}%`, backgroundColor: subject.color }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
