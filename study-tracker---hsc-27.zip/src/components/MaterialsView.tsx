import React, { useState } from 'react';
import { SubjectData, StudyMaterial } from '../types';
import { Plus, ExternalLink, Trash2 } from 'lucide-react';

interface MaterialsViewProps {
  subjects: SubjectData[];
  materials: StudyMaterial[];
  onAddMaterial: (material: StudyMaterial) => void;
  onDeleteMaterial: (index: number) => void;
}

export const MaterialsView: React.FC<MaterialsViewProps> = ({
  subjects,
  materials,
  onAddMaterial,
  onDeleteMaterial
}) => {
  const [selectedSubject, setSelectedSubject] = useState(0);
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !url.trim()) return;

    let finalUrl = url.trim();
    if (!/^https?:\/\//i.test(finalUrl)) {
      finalUrl = 'https://' + finalUrl;
    }

    onAddMaterial({
      subjectIndex: Number(selectedSubject),
      title: title.trim(),
      url: finalUrl
    });

    setTitle('');
    setUrl('');
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <div className="text-xs uppercase tracking-wider font-bold text-[var(--mu)]">
          Material
        </div>
        <h1 className="font-serif text-2xl font-bold">Guides &amp; Past Questions</h1>
      </div>

      {/* Add New Card */}
      <form
        onSubmit={handleAdd}
        className="bg-[var(--card)] border border-[var(--bd)] rounded-2xl p-4 space-y-3 shadow-xs"
      >
        <div className="text-xs font-bold uppercase tracking-wider text-[var(--mu)]">
          Add Resource Link
        </div>

        <select
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(Number(e.target.value))}
          className="w-full p-2.5 rounded-xl border border-[var(--bd)] bg-[var(--bg)] text-[var(--tx)] text-sm focus:outline-hidden focus:ring-2 focus:ring-[var(--ac)]"
        >
          {subjects.map((subj, idx) => (
            <option key={subj.title} value={idx}>
              {subj.title}
            </option>
          ))}
        </select>

        <input
          type="text"
          placeholder="Title (e.g. 27th Batch Organic Chem Summary)"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full p-2.5 rounded-xl border border-[var(--bd)] bg-[var(--bg)] text-[var(--tx)] text-sm focus:outline-hidden focus:ring-2 focus:ring-[var(--ac)]"
        />

        <input
          type="text"
          placeholder="Link (Google Drive, PDF, Notion, Web URL)"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="w-full p-2.5 rounded-xl border border-[var(--bd)] bg-[var(--bg)] text-[var(--tx)] text-sm focus:outline-hidden focus:ring-2 focus:ring-[var(--ac)]"
        />

        <button
          type="submit"
          disabled={!title.trim() || !url.trim()}
          className="w-full py-2.5 px-4 bg-[var(--ac)] hover:brightness-110 disabled:opacity-50 text-white font-bold rounded-xl text-sm flex items-center justify-center gap-2 transition shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>Add Material</span>
        </button>
      </form>

      {/* List by Subject */}
      <div className="space-y-4">
        {subjects.map((subj, subjIdx) => {
          const subjMaterials = materials
            .map((item, originalIndex) => ({ item, originalIndex }))
            .filter(({ item }) => item.subjectIndex === subjIdx);

          if (subjMaterials.length === 0) return null;

          return (
            <div key={subj.title} className="space-y-2">
              <div
                className="font-bold text-xs uppercase tracking-wider pl-2 border-l-4"
                style={{ borderColor: subj.color, color: subj.color }}
              >
                {subj.title}
              </div>

              <div className="bg-[var(--card)] border border-[var(--bd)] rounded-2xl divide-y divide-[var(--bd)] overflow-hidden shadow-xs">
                {subjMaterials.map(({ item, originalIndex }) => (
                  <div
                    key={originalIndex}
                    className="p-3 flex items-center justify-between gap-3 text-sm hover:bg-[var(--bd)]/20 transition"
                  >
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-[var(--ac)] font-medium hover:underline truncate"
                    >
                      <ExternalLink className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.title}</span>
                    </a>

                    <button
                      onClick={() => onDeleteMaterial(originalIndex)}
                      className="p-1 text-[var(--mu)] hover:text-red-500 rounded-lg transition shrink-0"
                      title="Delete link"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {materials.length === 0 && (
          <div className="text-center py-8 text-sm text-[var(--mu)] bg-[var(--card)] border border-dashed border-[var(--bd)] rounded-2xl p-6">
            No study materials saved yet. Add your first Drive or PDF link above.
          </div>
        )}
      </div>
    </div>
  );
};
