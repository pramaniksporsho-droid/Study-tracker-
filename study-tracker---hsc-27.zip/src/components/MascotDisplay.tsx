import React from 'react';
import { MASCOTS } from '../data/syllabus';

interface MascotDisplayProps {
  id: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  animated?: boolean;
  className?: string;
}

export const MascotDisplay: React.FC<MascotDisplayProps> = ({
  id,
  size = 'md',
  animated = true,
  className = ''
}) => {
  const mascot = MASCOTS.find((m) => m.id === id) || MASCOTS[0];

  const sizeClasses = {
    sm: 'w-10 h-10 text-2xl',
    md: 'w-16 h-16 text-4xl',
    lg: 'w-24 h-24 text-6xl',
    xl: 'w-32 h-32 text-7xl'
  };

  const animClass = animated ? (size === 'xl' ? 'animate-bob-fast' : 'animate-bob') : '';

  if (mascot.id === 'owl') {
    return (
      <div className={`flex items-center justify-center shrink-0 ${sizeClasses[size]} ${animClass} ${className}`}>
        <svg className="w-full h-full" viewBox="0 0 100 100" aria-hidden="true">
          <ellipse cx="17" cy="64" rx="8" ry="18" fill="var(--ac)" transform="rotate(12 17 64)" />
          <ellipse cx="83" cy="64" rx="8" ry="18" fill="var(--ac)" transform="rotate(-12 83 64)" />
          <ellipse cx="50" cy="60" rx="33" ry="32" fill="var(--ac)" />
          <ellipse cx="50" cy="72" rx="19" ry="18" fill="#fff" opacity=".85" />
          <circle cx="37" cy="52" r="13" fill="#fff" />
          <circle cx="63" cy="52" r="13" fill="#fff" />
          <circle cx="39" cy="53" r="6.5" fill="#1b1f3b" />
          <circle cx="61" cy="53" r="6.5" fill="#1b1f3b" />
          <circle cx="41" cy="50.5" r="2.2" fill="#fff" />
          <circle cx="63" cy="50.5" r="2.2" fill="#fff" />
          <polygon points="45,60 55,60 50,70" fill="#f59e0b" />
          <polygon points="18,30 50,14 82,30 50,44" fill="#1b1f3b" />
          <rect x="38" y="36" width="24" height="10" rx="3" fill="#1b1f3b" />
          <line x1="78" y1="31" x2="84" y2="48" stroke="#f59e0b" strokeWidth="2.5" />
          <circle cx="84" cy="50" r="3" fill="#f59e0b" />
          <path d="M40 91l-3 6M50 92v6M60 91l3 6" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round" />
        </svg>
      </div>
    );
  }

  return (
    <div
      className={`rounded-full bg-[var(--bd)] flex items-center justify-center shrink-0 ${sizeClasses[size]} ${animClass} ${className}`}
      aria-hidden="true"
    >
      <span>{mascot.emoji || '🦉'}</span>
    </div>
  );
};
