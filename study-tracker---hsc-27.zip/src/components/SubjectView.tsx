import React from 'react';
import { SubjectData } from '../types';
import { ArrowLeft, Check, Lock } from 'lucide-react';

interface SubjectViewProps {
  subject: SubjectData;
  subjectIndex: number;
  progress: Record<string, number>;
  onToggleStep: (subjectIndex: number, chapterIndex: number, stepIndex: number) => void;
  onBack: () => void;
}

export const SubjectView: React.FC<SubjectViewProps> = ({
  subject,
  subjectIndex,
  progress,
  onToggleStep,
  onBack
}) => {
  // Compute chapters list
  const chaptersList: { name: string; group: string; chapterNum: number }[] = [];
  let totalChapters = 0;

  subject.groups.forEach((group) => {
    const names = group[1].split('|');
    names.forEach((name) => {
      totalChapters++;
      chaptersList.push({
        name,
        group: group[0],
        chapterNum: totalChapters
      });
    });
  });

  const getChapterFinishedCount = (chapNum: number) => {
    return subject.steps.filter((_, stepIdx) => progress[`${subjectIndex}.${chapNum}.${stepIdx}`]).length;
  };

  const isChapterComplete = (chapNum: number) => {
    return getChapterFinishedCount(chapNum) === subject.steps.length;
  };

  // Compute overall stats
  let totalTicks = 0;
  const maxPossibleTicks = totalChapters * subject.steps.length;
  let finishedChapters = 0;

  for (let c = 1; c <= totalChapters; c++) {
    const doneSteps = getChapterFinishedCount(c);
    totalTicks += doneSteps;
    if (doneSteps === subject.steps.length) {
      finishedChapters++;
    }
  }

  const percent = maxPossibleTicks > 0 ? Math.round((totalTicks / maxPossibleTicks) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* Top Navigation */}
      <div className="flex items-center gap-3">
        <button
          onClick={onBack}
          className="p-2.5 rounded-xl border border-[var(--bd)] bg-[var(--card)] hover:bg-[var(--bd)] transition"
          aria-label="Back to subjects"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="font-serif text-2xl font-bold truncate" style={{ color: subject.color }}>
            {subject.title}
          </h1>
        </div>
      </div>

      {/* Progress Bar & Summary */}
      <div className="space-y-1.5">
        <div className="w-full h-2.5 bg-[var(--bd)] rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-300"
            style={{ width: `${percent}%`, backgroundColor: subject.color }}
          />
        </div>
        <div className="text-xs font-medium text-[var(--mu)]">
          {finishedChapters}/{totalChapters} chapters done · {percent}%
        </div>
      </div>

      {/* Grouped Chapters */}
      <div className="space-y-4">
        {subject.groups.map((group) => {
          const groupName = group[0];
          const groupChaps = chaptersList.filter((c) => c.group === groupName);

          return (
            <div key={groupName} className="space-y-2">
              <div
                className="font-bold text-sm pl-2 py-0.5 border-l-4"
                style={{ borderColor: subject.color, color: subject.color }}
              >
                {groupName}
              </div>

              <div className="space-y-2.5">
                {groupChaps.map((chap) => {
                  const doneCount = getChapterFinishedCount(chap.chapterNum);
                  const isDone = doneCount === subject.steps.length;

                  return (
                    <div
                      key={chap.chapterNum}
                      className={`bg-[var(--card)] border rounded-2xl p-3.5 transition shadow-xs ${
                        isDone ? 'border-emerald-500/80 bg-emerald-50/20 dark:bg-emerald-950/10' : 'border-[var(--bd)]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-3 gap-2">
                        <div className="font-semibold text-sm sm:text-base flex items-center gap-2">
                          <span className="text-[var(--mu)] text-xs font-bold w-5">
                            {chap.chapterNum}
                          </span>
                          <span className="truncate">{chap.name}</span>
                        </div>
                        <div
                          className={`text-xs font-medium px-2 py-0.5 rounded-full shrink-0 flex items-center gap-1 ${
                            isDone
                              ? 'bg-emerald-600 text-white font-bold'
                              : 'bg-[var(--bd)] text-[var(--mu)]'
                          }`}
                        >
                          <span>{doneCount}/{subject.steps.length}</span>
                          {isDone && <Lock className="w-3 h-3 ml-0.5" />}
                        </div>
                      </div>

                      {/* Step buttons grid */}
                      <div className="grid grid-cols-2 gap-2">
                        {subject.steps.map((stepName, stepIdx) => {
                          const isStepDone = Boolean(
                            progress[`${subjectIndex}.${chap.chapterNum}.${stepIdx}`]
                          );

                          return (
                            <button
                              key={stepIdx}
                              onClick={() => onToggleStep(subjectIndex, chap.chapterNum, stepIdx)}
                              className={`py-2.5 px-2 rounded-xl text-xs sm:text-sm font-semibold border transition text-center flex items-center justify-center gap-1.5 active:scale-[0.98] ${
                                isStepDone
                                  ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                                  : 'border-[var(--bd)] bg-transparent hover:bg-[var(--bd)]/50 text-[var(--tx)]'
                              }`}
                            >
                              {isStepDone && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                              <span className="truncate">{stepName}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
