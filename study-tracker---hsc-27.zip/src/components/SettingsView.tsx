import React, { useState, useEffect, useRef } from 'react';
import { UserPreferences, MascotInfo } from '../types';
import { MASCOTS, BUILDER_NAME, WHATSAPP_LINK } from '../data/syllabus';
import { MascotDisplay } from './MascotDisplay';
import {
  checkPushStatus,
  subscribeToPushNotifications,
  unsubscribeFromPushNotifications,
  sendTestPushNotification,
  PushStatus
} from '../utils/pushManager';
import {
  Bell,
  BellRing,
  Volume2,
  VolumeX,
  Sun,
  Moon,
  Download,
  Upload,
  MessageCircle,
  Clock,
  Sparkles,
  Smartphone,
  CheckCircle2,
  AlertTriangle,
  Info
} from 'lucide-react';

interface SettingsViewProps {
  userPrefs: UserPreferences;
  onUpdatePrefs: (newPrefs: Partial<UserPreferences>) => void;
  onBackupExport: () => void;
  onBackupImport: (file: File) => void;
  onToast: (msg: string) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  userPrefs,
  onUpdatePrefs,
  onBackupExport,
  onBackupImport,
  onToast
}) => {
  const [nameInput, setNameInput] = useState(userPrefs.name);
  const [pushStatus, setPushStatus] = useState<PushStatus>({
    isSupported: true,
    permission: 'default',
    isSubscribed: false
  });
  const [isSubscribing, setIsSubscribing] = useState(false);
  const [testCountdown, setTestCountdown] = useState<number | null>(null);
  const [showIosGuide, setShowIosGuide] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const refreshPushStatus = async () => {
    const status = await checkPushStatus();
    setPushStatus(status);
  };

  useEffect(() => {
    refreshPushStatus();
  }, []);

  // Handle countdown for delayed background test
  useEffect(() => {
    if (testCountdown === null) return;
    if (testCountdown <= 0) {
      setTestCountdown(null);
      return;
    }
    const timer = setTimeout(() => {
      setTestCountdown((prev) => (prev !== null ? prev - 1 : null));
    }, 1000);
    return () => clearTimeout(timer);
  }, [testCountdown]);

  const handleTogglePush = async () => {
    setIsSubscribing(true);
    try {
      if (pushStatus.isSubscribed) {
        const res = await unsubscribeFromPushNotifications();
        if (res.success) {
          onUpdatePrefs({ notificationsEnabled: false });
          onToast('Unsubscribed from background notifications');
        } else {
          onToast(res.error || 'Failed to unsubscribe');
        }
      } else {
        const res = await subscribeToPushNotifications(userPrefs);
        if (res.success) {
          onUpdatePrefs({ notificationsEnabled: true });
          onToast('🔔 Background notifications enabled! You will get reminders even when app is closed.');
        } else {
          onToast(res.error || 'Failed to enable notifications');
        }
      }
      await refreshPushStatus();
    } finally {
      setIsSubscribing(false);
    }
  };

  const handleImmediateTest = async () => {
    onToast('Sending test notification...');
    const res = await sendTestPushNotification(0, undefined, userPrefs);
    if (res.success) {
      onToast('Test notification sent! Check your notification tray.');
    } else {
      onToast(res.error || 'Failed to trigger test notification');
    }
  };

  const handleDelayedTest = async () => {
    const delay = 10;
    const res = await sendTestPushNotification(delay, undefined, userPrefs);
    if (res.success) {
      setTestCountdown(delay);
      onToast(`⏳ Background test scheduled in 10s! Close this tab or lock your phone NOW to test background delivery!`);
    } else {
      onToast(res.error || 'Failed to schedule delayed notification');
    }
  };

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdatePrefs({ name: nameInput.trim() });
    onToast('Name saved ✨');
  };

  const isDarkMode =
    document.documentElement.dataset.theme === 'dark' ||
    (!document.documentElement.dataset.theme &&
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-color-scheme: dark)').matches);

  const toggleTheme = () => {
    const newTheme = isDarkMode ? 'light' : 'dark';
    document.documentElement.dataset.theme = newTheme;
    onUpdatePrefs({ theme: newTheme });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <div className="text-xs uppercase tracking-wider font-bold text-[var(--mu)]">Settings</div>
        <h1 className="font-serif text-2xl font-bold">Preferences &amp; Notifications</h1>
      </div>

      {/* 1. BACKGROUND NOTIFICATIONS HUB */}
      <div className="bg-[var(--card)] border border-[var(--bd)] rounded-2xl p-4 sm:p-5 space-y-4 shadow-xs">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-[var(--ac)] flex items-center justify-center shrink-0">
              <BellRing className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm sm:text-base leading-tight">
                Background Study Nudges 😤
              </h2>
              <p className="text-xs text-[var(--mu)]">
                Get reminders even when you are NOT using the app or browser is closed
              </p>
            </div>
          </div>
        </div>

        {/* Current status banner */}
        {pushStatus.isSubscribed ? (
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3 flex items-start gap-2.5 text-xs text-emerald-800 dark:text-emerald-300">
            <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0 text-emerald-600 dark:text-emerald-400" />
            <div>
              <span className="font-bold">Active &amp; Connected:</span> Web Push Service Worker is registered. The server will deliver reminders directly to your device tray/lockscreen on schedule.
            </div>
          </div>
        ) : pushStatus.permission === 'denied' ? (
          <div className="bg-rose-500/10 border border-rose-500/30 rounded-xl p-3 flex items-start gap-2.5 text-xs text-rose-800 dark:text-rose-300">
            <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0 text-rose-600 dark:text-rose-400" />
            <div>
              <span className="font-bold">Notifications Blocked:</span> Your browser has blocked notifications for this site. Tap your browser URL bar lock/settings icon to toggle "Notifications" to "Allow", then reload.
            </div>
          </div>
        ) : (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 flex items-start gap-2.5 text-xs text-amber-800 dark:text-amber-300">
            <Info className="w-4 h-4 mt-0.5 shrink-0 text-amber-600 dark:text-amber-400" />
            <div>
              <span className="font-bold">Background notifications are off:</span> Tap "Turn On Background Nudges" below to grant permission and subscribe.
            </div>
          </div>
        )}

        {/* Action Toggle Button */}
        <div className="flex flex-col sm:flex-row gap-2 pt-1">
          <button
            onClick={handleTogglePush}
            disabled={isSubscribing}
            className={`flex-1 py-3 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition shadow-xs ${
              pushStatus.isSubscribed
                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                : 'bg-[var(--ac)] hover:brightness-110 text-white'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>
              {isSubscribing
                ? 'Connecting to push service...'
                : pushStatus.isSubscribed
                ? 'Turn Off Notifications'
                : 'Turn On Background Nudges'}
            </span>
          </button>
        </div>

        {/* Nudge Configuration */}
        <div className="pt-2 border-t border-[var(--bd)] space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <div>
              <label className="block text-xs font-bold text-[var(--mu)] mb-1 uppercase tracking-wider">
                Frequency (Interval)
              </label>
              <select
                value={userPrefs.intervalMinutes || 60}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  onUpdatePrefs({ intervalMinutes: val });
                  if (pushStatus.isSubscribed) {
                    subscribeToPushNotifications({ ...userPrefs, intervalMinutes: val });
                  }
                  onToast(`Interval set to every ${val} minutes`);
                }}
                className="w-full p-2.5 rounded-xl border border-[var(--bd)] bg-[var(--bg)] text-[var(--tx)] text-xs focus:ring-2 focus:ring-[var(--ac)]"
              >
                <option value={15}>Every 15 minutes (Intense sprint)</option>
                <option value={30}>Every 30 minutes</option>
                <option value={60}>Every 1 hour (Default)</option>
                <option value={120}>Every 2 hours</option>
                <option value={180}>Every 3 hours</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[var(--mu)] mb-1 uppercase tracking-wider">
                Nudge Personality
              </label>
              <select
                value={userPrefs.nudgeStyle || 'mixed'}
                onChange={(e) => {
                  const val = e.target.value as any;
                  onUpdatePrefs({ nudgeStyle: val });
                  if (pushStatus.isSubscribed) {
                    subscribeToPushNotifications({ ...userPrefs, nudgeStyle: val });
                  }
                  onToast('Nudge style updated');
                }}
                className="w-full p-2.5 rounded-xl border border-[var(--bd)] bg-[var(--bg)] text-[var(--tx)] text-xs focus:ring-2 focus:ring-[var(--ac)]"
              >
                <option value="angry">Angry Desi Mascot 😤 ('কিরে তোর পড়ার ইচ্ছা নাই? 😡')</option>
                <option value="motivational">Motivational Coach 🏆 ('Consistency defeats talent')</option>
                <option value="mixed">Mixed Mode 🎲 (Alternates strict &amp; inspiring)</option>
              </select>
            </div>
          </div>

          {/* Quiet Hours toggle */}
          <div className="flex items-center justify-between text-xs pt-1">
            <span className="text-[var(--tx)] font-medium">
              🌙 Quiet hours (No alerts between 11 PM – 7 AM)
            </span>
            <input
              type="checkbox"
              checked={userPrefs.quietHoursEnabled !== false}
              onChange={(e) => {
                const checked = e.target.checked;
                onUpdatePrefs({ quietHoursEnabled: checked });
                if (pushStatus.isSubscribed) {
                  subscribeToPushNotifications({ ...userPrefs, quietHoursEnabled: checked });
                }
              }}
              className="w-4 h-4 rounded text-[var(--ac)]"
            />
          </div>
        </div>

        {/* Live Background Verification Tests */}
        <div className="pt-3 border-t border-[var(--bd)] space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-[var(--mu)]">
            Verify Background Delivery
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <button
              onClick={handleImmediateTest}
              className="py-2.5 px-3 rounded-xl border border-[var(--bd)] bg-[var(--bg)] hover:bg-[var(--bd)]/40 font-semibold text-xs flex items-center justify-center gap-1.5 transition"
            >
              <Sparkles className="w-3.5 h-3.5 text-[var(--ac)]" />
              <span>⚡ Send Instant Push</span>
            </button>

            <button
              onClick={handleDelayedTest}
              disabled={testCountdown !== null}
              className="py-2.5 px-3 rounded-xl border border-[var(--ac)]/60 bg-[var(--ac)]/10 hover:bg-[var(--ac)]/20 text-[var(--tx)] font-semibold text-xs flex items-center justify-center gap-1.5 transition"
            >
              <Clock className="w-3.5 h-3.5 text-[var(--ac)]" />
              <span>
                {testCountdown !== null
                  ? `Sending in ${testCountdown}s (close tab now!)...`
                  : '⏳ Test 10s Delay (Close tab to test)'}
              </span>
            </button>
          </div>

          {testCountdown !== null && (
            <div className="p-3 bg-amber-500/20 border border-amber-500/40 rounded-xl text-center text-xs animate-pulse">
              <span className="font-bold">⏰ Triggering in {testCountdown} seconds!</span>
              <p className="mt-0.5 text-[var(--mu)]">
                Quickly close this tab, switch apps, or lock your phone to see the notification arrive while you are not using the app!
              </p>
            </div>
          )}

          {/* iOS Safari Guide Accordion */}
          <div className="pt-1">
            <button
              onClick={() => setShowIosGuide(!showIosGuide)}
              className="text-[11px] text-[var(--mu)] underline hover:text-[var(--tx)] flex items-center gap-1"
            >
              <Smartphone className="w-3 h-3" />
              <span>Using iPhone/iPad (iOS)? Tap here for quick setup instructions</span>
            </button>

            {showIosGuide && (
              <div className="mt-2 p-3 rounded-xl bg-[var(--bg)] border border-[var(--bd)] text-xs text-[var(--mu)] space-y-1.5">
                <div className="font-bold text-[var(--tx)]">iOS 16.4+ Web Push Instructions:</div>
                <div>1. In Safari, tap the <b>Share</b> button in the bottom toolbar.</div>
                <div>2. Scroll down and tap <b>Add to Home Screen</b>.</div>
                <div>3. Open the app from your Home Screen icon and tap <b>"Turn On Background Nudges"</b>.</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2. Student Name Card */}
      <form
        onSubmit={handleSaveName}
        className="bg-[var(--card)] border border-[var(--bd)] rounded-2xl p-4 space-y-3 shadow-xs"
      >
        <div className="text-xs font-bold uppercase tracking-wider text-[var(--mu)]">
          Your Name
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
            placeholder="Enter your name (e.g. Sporsho)"
            maxLength={25}
            className="flex-1 p-2.5 rounded-xl border border-[var(--bd)] bg-[var(--bg)] text-[var(--tx)] text-sm focus:ring-2 focus:ring-[var(--ac)]"
          />
          <button
            type="submit"
            className="py-2.5 px-4 bg-[var(--ac)] hover:brightness-110 text-white font-bold rounded-xl text-sm transition shrink-0"
          >
            Save
          </button>
        </div>
      </form>

      {/* 3. Mascot Selection */}
      <div className="bg-[var(--card)] border border-[var(--bd)] rounded-2xl p-4 space-y-3 shadow-xs">
        <div className="text-xs font-bold uppercase tracking-wider text-[var(--mu)]">
          Choose Your Study Mascot
        </div>
        <div className="grid grid-cols-3 gap-2">
          {MASCOTS.map((m) => {
            const isSelected = userPrefs.mascot === m.id;
            return (
              <button
                key={m.id}
                onClick={() => {
                  onUpdatePrefs({ mascot: m.id });
                  onToast(`${m.name} selected as your mascot!`);
                }}
                className={`p-2.5 rounded-2xl border flex flex-col items-center justify-center gap-1.5 transition ${
                  isSelected
                    ? 'border-[var(--ac)] bg-[var(--bd)]/60 shadow-xs'
                    : 'border-[var(--bd)] bg-transparent hover:bg-[var(--bd)]/20'
                }`}
              >
                <MascotDisplay id={m.id} size="sm" animated={isSelected} />
                <span className="text-[11px] font-semibold truncate w-full text-center">
                  {m.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. Sound & Theme Quick Toggles */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="bg-[var(--card)] border border-[var(--bd)] rounded-2xl p-3.5 space-y-2 shadow-xs">
          <div className="text-xs font-bold uppercase tracking-wider text-[var(--mu)]">Sound</div>
          <button
            onClick={() => {
              const newMute = !userPrefs.mute;
              onUpdatePrefs({ mute: newMute });
              onToast(newMute ? 'Sound muted 🔇' : 'Sound enabled 🔊');
            }}
            className="w-full py-2 px-3 rounded-xl border border-[var(--bd)] bg-[var(--bg)] hover:bg-[var(--bd)]/40 font-semibold text-xs flex items-center justify-center gap-2 transition"
          >
            {userPrefs.mute ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-500" />}
            <span>{userPrefs.mute ? 'Sound Off' : 'Sound On'}</span>
          </button>
        </div>

        <div className="bg-[var(--card)] border border-[var(--bd)] rounded-2xl p-3.5 space-y-2 shadow-xs">
          <div className="text-xs font-bold uppercase tracking-wider text-[var(--mu)]">Theme</div>
          <button
            onClick={toggleTheme}
            className="w-full py-2 px-3 rounded-xl border border-[var(--bd)] bg-[var(--bg)] hover:bg-[var(--bd)]/40 font-semibold text-xs flex items-center justify-center gap-2 transition"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-500" />}
            <span>{isDarkMode ? 'Light Mode' : 'Dark Mode'}</span>
          </button>
        </div>
      </div>

      {/* 5. Backup & Restore */}
      <div className="bg-[var(--card)] border border-[var(--bd)] rounded-2xl p-4 space-y-3 shadow-xs">
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-[var(--mu)]">
            Backup &amp; Restore
          </div>
          <p className="text-xs text-[var(--mu)] mt-0.5">
            Export your syllabus progress, settings, and materials to a JSON file.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onBackupExport}
            className="py-2.5 px-3 rounded-xl bg-[var(--ac)] hover:brightness-110 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-xs"
          >
            <Download className="w-4 h-4" />
            <span>Export Backup</span>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="py-2.5 px-3 rounded-xl border border-[var(--bd)] bg-[var(--bg)] hover:bg-[var(--bd)]/40 font-bold text-xs flex items-center justify-center gap-1.5 transition"
          >
            <Upload className="w-4 h-4" />
            <span>Import Backup</span>
          </button>
        </div>

        {/* Direct Project index.zip Download */}
        <div className="pt-2 border-t border-[var(--bd)] flex items-center justify-between gap-3">
          <div>
            <div className="text-xs font-bold text-[var(--tx)] flex items-center gap-1.5">
              <span>Full Project index.zip</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 font-bold px-1.5 py-0.5 rounded">Ready</span>
            </div>
            <div className="text-[11px] text-[var(--mu)]">
              Contains complete source code, PWA files, sw.js, and standalone index.html.
            </div>
          </div>
          <a
            href="/index.zip"
            download="index.zip"
            className="py-2 px-3 bg-[var(--card)] hover:bg-[var(--bd)] border border-[var(--bd)] font-bold text-xs rounded-xl flex items-center gap-1.5 transition text-[var(--tx)] shrink-0 shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-[var(--ac)]" />
            <span>Download ZIP</span>
          </a>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) {
              onBackupImport(file);
              e.target.value = '';
            }
          }}
        />
      </div>

      {/* 6. About Builder & Contact */}
      <div className="bg-[var(--card)] border border-[var(--bd)] rounded-2xl p-4 space-y-2.5 shadow-xs">
        <div className="text-xs font-bold uppercase tracking-wider text-[var(--mu)]">About</div>
        <div className="text-sm">
          Built with ❤️ for HSC 27 students by <b>{BUILDER_NAME}</b>.
        </div>
        <p className="text-xs text-[var(--mu)]">
          Questions, bug reports, or feature ideas? Message directly on WhatsApp:
        </p>
        <a
          href={WHATSAPP_LINK}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition shadow-xs"
        >
          <MessageCircle className="w-4 h-4" />
          <span>WhatsApp: 01853-152415</span>
        </a>
      </div>
    </div>
  );
};
