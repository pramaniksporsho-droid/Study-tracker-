import React, { useEffect, useState } from 'react';
import { MascotDisplay } from './MascotDisplay';
import { MASCOTS, CELEBRATION_MESSAGES } from '../data/syllabus';

interface CelebrationModalProps {
  subjectTitle: string;
  chapterNum: number;
  mascotId: string;
  onClose: () => void;
}

export const CelebrationModal: React.FC<CelebrationModalProps> = ({
  subjectTitle,
  chapterNum,
  mascotId,
  onClose
}) => {
  const [randomMessage, setRandomMessage] = useState('');
  const mascot = MASCOTS.find((m) => m.id === mascotId) || MASCOTS[0];

  useEffect(() => {
    const msg = CELEBRATION_MESSAGES[Math.floor(Math.random() * CELEBRATION_MESSAGES.length)];
    setRandomMessage(msg);
  }, []);

  const confettiItems = Array.from({ length: 22 }, (_, i) => ({
    id: i,
    char: ['🎉', '✨', '⭐', '🎊', '🔥', '🏆'][i % 6],
    left: `${(i * 4.5 + Math.random() * 3) % 96}%`,
    delay: `${(i * 0.12).toFixed(2)}s`,
    duration: `${(2.2 + Math.random() * 1).toFixed(2)}s`
  }));

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
    >
      {/* Confetti particles */}
      {confettiItems.map((item) => (
        <span
          key={item.id}
          className="fixed -top-8 text-2xl z-50 pointer-events-none animate-confetti"
          style={{
            left: item.left,
            animationDelay: item.delay,
            animationDuration: item.duration
          }}
        >
          {item.char}
        </span>
      ))}

      {/* Modal Dialog Card */}
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm bg-[var(--card)] border border-[var(--bd)] rounded-3xl p-6 text-center shadow-2xl relative z-10 space-y-4"
      >
        <div className="flex justify-center">
          <MascotDisplay id={mascotId} size="xl" />
        </div>

        <div>
          <div className="text-xs uppercase font-bold tracking-wider text-[var(--mu)]">
            {mascot.name} says:
          </div>
          <h2 className="font-serif text-xl sm:text-2xl font-bold mt-1 text-[var(--tx)]">
            🎉 {subjectTitle} · Chapter {chapterNum}
          </h2>
          <p className="mt-2 text-base font-semibold text-[var(--tx)] leading-relaxed">
            {randomMessage}
          </p>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 px-4 bg-[var(--ac)] hover:brightness-110 text-white font-bold rounded-xl text-sm transition shadow-md active:scale-95"
        >
          Keep Going 🚀
        </button>
      </div>
    </div>
  );
};
