import React from 'react';
import { SubjectData, UserPreferences } from '../types';
import { MascotDisplay } from './MascotDisplay';
import { Bell, BellRing, Sparkles, ChevronRight, ShieldCheck, Download } from 'lucide-react';

interface HomeViewProps {
  userPrefs: UserPreferences;
  subjects: SubjectData[];
  getSubjectStats: (subjectIndex: number) => { finished: number; total: number; percent: number };
  onSelectSubject: (subjectIndex: number) => void;
  randomQuote: string;
  isPushActive: boolean;
  onOpenNotificationSettings: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  userPrefs,
  subjects,
  getSubjectStats,
  onSelectSubject,
  randomQuote,
  isPushActive,
  onOpenNotificationSettings
}) => {
  const getGreeting = () => {
    const h = new Date().getHours();
    if (h < 5) return 'Late night';
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    if (h < 21) return 'Good evening';
    return 'Good night';
  };

  return (
    <div className="space-y-4">
      {/* Brand banner & Download index.zip quick action */}
      <div className="flex items-center justify-between gap-2 bg-[var(--card)] border border-[var(--bd)] rounded-full py-1.5 px-3.5 shadow-xs">
        <span className="text-[11px] sm:text-xs font-black tracking-wider uppercase text-[var(--ac)] truncate">
          Minimal Study Tracker for HSC27
        </span>
        <a
          href="/index.zip"
          download="index.zip"
          title="Download complete index.zip package"
          className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[var(--ac)]/10 hover:bg-[var(--ac)] text-[var(--ac)] hover:text-white rounded-full text-[11px] font-bold transition shrink-0 border border-[var(--ac)]/30"
        >
          <Download className="w-3.5 h-3.5" />
          <span>index.zip</span>
        </a>
      </div>

      {/* Hero card */}
      <div className="flex items-center justify-between gap-3 bg-[var(--card)] border border-[var(--bd)] rounded-2xl p-4 sm:p-5 shadow-xs">
        <div className="flex-1 min-w-0 pr-2">
          <div className="text-sm font-medium text-[var(--mu)] flex items-center gap-1.5">
            <span>{getGreeting()}</span>
            <span>👋</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold leading-tight mt-1 truncate">
            {userPrefs.name || 'Future Topper'}
          </h1>
          <div className="text-xs text-[var(--mu)] mt-1 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-[var(--ac)]" />
            <span>Target: Complete HSC 27 Syllabus</span>
          </div>
        </div>
        <MascotDisplay id={userPrefs.mascot} size="lg" />
      </div>

      {/* Background Notification Status banner */}
      {isPushActive ? (
        <div
          onClick={onOpenNotificationSettings}
          className="cursor-pointer bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3.5 flex items-center justify-between transition hover:bg-emerald-500/15"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-emerald-700 dark:text-emerald-300 flex items-center gap-1.5">
                <span>Background Nudges Active</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              </div>
              <div className="text-[11px] text-[var(--mu)]">
                Delivers hourly nudges even when app &amp; browser are closed.
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
        </div>
      ) : (
        <div
          onClick={onOpenNotificationSettings}
          className="cursor-pointer bg-[var(--card)] border border-amber-500/40 rounded-xl p-3.5 shadow-xs transition hover:border-amber-500 flex items-center justify-between gap-3 group"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <BellRing className="w-5 h-5 animate-bounce" />
            </div>
            <div>
              <div className="text-xs font-bold text-[var(--tx)] flex items-center gap-1">
                <span>Get Nudges When App is Closed</span>
                <span className="bg-amber-500 text-white text-[10px] px-1.5 py-0.2 rounded font-semibold">New</span>
              </div>
              <div className="text-[11px] text-[var(--mu)]">
                Tap to enable background notifications for phone / computer.
              </div>
            </div>
          </div>
          <button className="text-xs font-bold text-white bg-[var(--ac)] hover:brightness-110 rounded-lg px-3 py-1.5 shrink-0 shadow-xs">
            Enable
          </button>
        </div>
      )}

      {/* Quote card */}
      <div className="bg-gradient-to-br from-[#1b1f3b] via-[#23274e] to-[#2c2a55] text-[#f3e6c4] border border-[#b8892b]/50 rounded-[18px] p-4 sm:p-5 font-serif italic text-base sm:text-lg leading-relaxed relative shadow-md">
        <span className="text-4xl sm:text-5xl text-[var(--ac)] font-serif leading-none mr-1.5 align-[-10px] select-none inline-block">“</span>
        <span>{randomQuote}</span>
      </div>

      {/* Subject Section Header */}
      <div className="flex items-center justify-between pt-1">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[var(--mu)]">
          Subjects
        </h2>
        <span className="text-xs font-semibold text-[var(--mu)]">
          {subjects.length} subjects
        </span>
      </div>

      {/* Subjects Grid */}
      <div className="grid grid-cols-2 gap-3">
        {subjects.map((subj, idx) => {
          const stats = getSubjectStats(idx);
          return (
            <button
              key={subj.title}
              onClick={() => onSelectSubject(idx)}
              className="text-left bg-[var(--card)] border border-[var(--bd)] rounded-[16px] p-3.5 sm:p-4 transition-all duration-200 shadow-xs hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.99] flex flex-col justify-between group cursor-pointer"
              style={{ borderTop: `4px solid ${subj.color}` }}
            >
              <div className="w-full">
                <b className="block text-sm sm:text-base font-bold truncate mb-1 text-[var(--tx)] group-hover:text-[var(--ac)] transition-colors">
                  {subj.title}
                </b>
                <div className="text-[11px] font-medium text-[var(--mu)] mb-2.5">
                  {stats.finished}/{stats.total} chapters
                </div>
              </div>

              <div className="w-full pt-1">
                <div className="w-full h-2 bg-[var(--bd)] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500 ease-out"
                    style={{ width: `${stats.percent}%`, backgroundColor: subj.color }}
                  />
                </div>
                <div className="mt-1.5 flex items-center justify-between text-xs">
                  <span className="text-[10px] uppercase font-bold text-[var(--mu)] tracking-wider">Progress</span>
                  <span className="font-bold text-xs" style={{ color: subj.color }}>
                    {stats.percent}%
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
