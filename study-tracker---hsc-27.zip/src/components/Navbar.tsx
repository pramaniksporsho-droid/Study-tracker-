import React from 'react';
import { ViewType } from '../types';

interface NavbarProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  notificationsActive: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate, notificationsActive }) => {
  const navItems: { view: ViewType; label: string; icon: string }[] = [
    { view: 'home', label: 'Home', icon: '🏠' },
    { view: 'prog', label: 'Progress', icon: '📈' },
    { view: 'mat', label: 'Material', icon: '📚' },
    { view: 'set', label: 'Settings', icon: '⚙️' }
  ];

  return (
    <nav className="fixed left-0 right-0 bottom-0 z-40 bg-[var(--card)] border-t border-[var(--bd)] max-w-[720px] mx-auto pb-[calc(env(safe-area-inset-bottom,0px)+8px)] pt-2 px-3 shadow-lg">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = currentView === item.view || (currentView === 'subj' && item.view === 'home');
          return (
            <button
              key={item.view}
              onClick={() => onNavigate(item.view)}
              className={`relative flex-1 py-1.5 flex flex-col items-center justify-center transition-colors text-xs ${
                isActive ? 'text-[var(--ac)] font-bold' : 'text-[var(--mu)] font-medium'
              }`}
            >
              <span className="text-xl mb-0.5">{item.icon}</span>
              <span>{item.label}</span>
              {item.view === 'set' && notificationsActive && (
                <span
                  title="Background notifications active"
                  className="absolute top-1 right-[26%] w-2 h-2 rounded-full bg-emerald-500 animate-pulse"
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
