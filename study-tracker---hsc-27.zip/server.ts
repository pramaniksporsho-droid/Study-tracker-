import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import webpush from 'web-push';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3000', 10);
const DATA_DIR = path.resolve(__dirname, 'data');
const VAPID_FILE = path.join(DATA_DIR, 'vapid-keys.json');
const SUBS_FILE = path.join(DATA_DIR, 'subscriptions.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// 1. Initialize or load VAPID Keys
interface VapidKeys {
  publicKey: string;
  privateKey: string;
}

let vapidKeys: VapidKeys;
if (fs.existsSync(VAPID_FILE)) {
  try {
    vapidKeys = JSON.parse(fs.readFileSync(VAPID_FILE, 'utf-8'));
  } catch (err) {
    vapidKeys = webpush.generateVAPIDKeys();
    fs.writeFileSync(VAPID_FILE, JSON.stringify(vapidKeys, null, 2));
  }
} else {
  vapidKeys = webpush.generateVAPIDKeys();
  fs.writeFileSync(VAPID_FILE, JSON.stringify(vapidKeys, null, 2));
}

webpush.setVapidDetails(
  'mailto:support@studytracker.app',
  vapidKeys.publicKey,
  vapidKeys.privateKey
);

// 2. Load or initialize subscriptions
interface PushClientConfig {
  endpoint: string;
  keys: {
    p256dh: string;
    auth: string;
  };
}

interface StoredSubscription {
  id: string;
  subscription: PushClientConfig;
  userName?: string;
  intervalMinutes: number;
  nudgeStyle: 'angry' | 'motivational' | 'mixed';
  quietHoursEnabled: boolean;
  quietHoursStart: number;
  quietHoursEnd: number;
  lastNudgeSentAt: number;
  createdAt: number;
}

let subscriptions: StoredSubscription[] = [];

function loadSubscriptions() {
  if (fs.existsSync(SUBS_FILE)) {
    try {
      subscriptions = JSON.parse(fs.readFileSync(SUBS_FILE, 'utf-8'));
    } catch (e) {
      subscriptions = [];
    }
  }
}

function saveSubscriptions() {
  try {
    fs.writeFileSync(SUBS_FILE, JSON.stringify(subscriptions, null, 2));
  } catch (e) {
    console.error('Failed to save subscriptions:', e);
  }
}

loadSubscriptions();

// Quotes for background notifications
const ANGRY_QUOTES = [
  'কিরে তোর পড়ার ইচ্ছা নাই? 😡 বাপ-মাকে লজ্জায় ফেলিস না!',
  'তুই কি ফেল করবি পরীক্ষায়? 😠🤬 বই খোল এখনই!',
  'লজ্জা আছে? 😤 HSC27 কিন্তু আর বেশি দূরে না!',
  'বাপ-মাকে লজ্জায় ফেলিস না। 😡 এখনই রিভিশন দে!',
  'পড়তেসিস তুই? নাকি শুধু স্ক্রল করতেছিস? 🤨😠',
  'আজকের ফাঁকি কালকের কান্না! 😤 বই খোলো!'
];

const MOTIVATIONAL_QUOTES = [
  'Consistency defeats talent every time. Show up today! 🌟',
  'One chapter closer than yesterday. You can do this! 🎯',
  'Discipline beats motivation. Study now, celebrate later! 🏆',
  'Your future self is counting on what you do today. 💪',
  'Small steps every single day build an unbeatable topper! 🚀',
  'Turn off distractions, turn on your superpower: FOCUS! ✨'
];

function getRandomQuote(style: string, name?: string): { title: string; body: string } {
  const salutation = name ? `${name}! ` : '';
  if (style === 'angry') {
    const q = ANGRY_QUOTES[Math.floor(Math.random() * ANGRY_QUOTES.length)];
    return {
      title: '😤 Study Tracker Alert',
      body: salutation + q
    };
  } else if (style === 'motivational') {
    const q = MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)];
    return {
      title: '🌟 Daily HSC27 Motivation',
      body: salutation + q
    };
  } else {
    // Mixed
    const isAngry = Math.random() > 0.4;
    return getRandomQuote(isAngry ? 'angry' : 'motivational', name);
  }
}

// Helper to send push
async function sendPushToSubscription(
  sub: StoredSubscription,
  payload: { title: string; body: string; url?: string; tag?: string }
): Promise<boolean> {
  try {
    const stringified = JSON.stringify({
      title: payload.title,
      body: payload.body,
      url: payload.url || '/',
      tag: payload.tag || 'study-nudge-' + Date.now(),
      icon: '/pwa-192x192.png',
      badge: '/pwa-192x192.png',
      vibrate: [250, 100, 250, 100, 250]
    });

    await webpush.sendNotification(sub.subscription as any, stringified);
    sub.lastNudgeSentAt = Date.now();
    saveSubscriptions();
    return true;
  } catch (error: any) {
    console.error('Push error for endpoint:', sub.subscription.endpoint, error.statusCode);
    // If expired or gone (404 / 410), remove from subscriptions
    if (error.statusCode === 404 || error.statusCode === 410) {
      subscriptions = subscriptions.filter((s) => s.subscription.endpoint !== sub.subscription.endpoint);
      saveSubscriptions();
    }
    return false;
  }
}

// 3. Periodic Background Nudge Runner
// Checks subscriptions every 60 seconds
setInterval(async () => {
  const now = Date.now();
  const currentHour = new Date().getHours();

  for (const sub of subscriptions) {
    // Check quiet hours
    if (sub.quietHoursEnabled) {
      if (sub.quietHoursStart > sub.quietHoursEnd) {
        // e.g. 23 (11 PM) to 7 (7 AM)
        if (currentHour >= sub.quietHoursStart || currentHour < sub.quietHoursEnd) {
          continue;
        }
      } else {
        if (currentHour >= sub.quietHoursStart && currentHour < sub.quietHoursEnd) {
          continue;
        }
      }
    }

    const intervalMs = (sub.intervalMinutes || 60) * 60 * 1000;
    if (now - (sub.lastNudgeSentAt || 0) >= intervalMs) {
      const quote = getRandomQuote(sub.nudgeStyle || 'mixed', sub.userName);
      console.log(`[Push Nudge] Sending background reminder to ${sub.userName || 'Student'} (${sub.subscription.endpoint.slice(0, 35)}...)`);
      await sendPushToSubscription(sub, {
        title: quote.title,
        body: quote.body,
        tag: 'background-nudge'
      });
    }
  }
}, 60 * 1000);

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Routes
  app.get('/api/push/public-key', (req: Request, res: Response) => {
    res.json({ publicKey: vapidKeys.publicKey });
  });

  app.post('/api/push/subscribe', (req: Request, res: Response) => {
    const { subscription, userName, intervalMinutes, nudgeStyle, quietHoursEnabled, quietHoursStart, quietHoursEnd } = req.body;
    if (!subscription || !subscription.endpoint || !subscription.keys) {
      return res.status(400).json({ error: 'Invalid push subscription' });
    }

    const existingIndex = subscriptions.findIndex((s) => s.subscription.endpoint === subscription.endpoint);
    const updatedSub: StoredSubscription = {
      id: subscription.endpoint,
      subscription,
      userName: userName || '',
      intervalMinutes: intervalMinutes ? parseInt(intervalMinutes, 10) : 60,
      nudgeStyle: nudgeStyle || 'mixed',
      quietHoursEnabled: quietHoursEnabled !== undefined ? Boolean(quietHoursEnabled) : true,
      quietHoursStart: quietHoursStart !== undefined ? parseInt(quietHoursStart, 10) : 23,
      quietHoursEnd: quietHoursEnd !== undefined ? parseInt(quietHoursEnd, 10) : 7,
      lastNudgeSentAt: Date.now(),
      createdAt: existingIndex >= 0 ? subscriptions[existingIndex].createdAt : Date.now()
    };

    if (existingIndex >= 0) {
      subscriptions[existingIndex] = updatedSub;
    } else {
      subscriptions.push(updatedSub);
    }
    saveSubscriptions();

    res.json({
      success: true,
      message: 'Successfully subscribed to background study notifications!',
      activeSubscribers: subscriptions.length
    });
  });

  app.post('/api/push/unsubscribe', (req: Request, res: Response) => {
    const { endpoint } = req.body;
    if (!endpoint) {
      return res.status(400).json({ error: 'Endpoint is required' });
    }
    subscriptions = subscriptions.filter((s) => s.subscription.endpoint !== endpoint);
    saveSubscriptions();
    res.json({ success: true, message: 'Unsubscribed from push notifications.' });
  });

  // Test push notification (immediate or delayed)
  app.post('/api/push/test', async (req: Request, res: Response) => {
    const { subscription, delaySeconds = 0, customMessage, userName, nudgeStyle } = req.body;
    if (!subscription || !subscription.endpoint) {
      return res.status(400).json({ error: 'Push subscription required' });
    }

    const quote = customMessage
      ? { title: '📚 Study Tracker Test', body: customMessage }
      : getRandomQuote(nudgeStyle || 'angry', userName);

    const delay = parseInt(delaySeconds, 10) || 0;

    if (delay > 0) {
      // Schedule background delivery
      setTimeout(async () => {
        try {
          const payload = JSON.stringify({
            title: quote.title,
            body: quote.body,
            url: '/',
            tag: 'background-test-' + Date.now(),
            icon: '/pwa-192x192.png',
            badge: '/pwa-192x192.png',
            vibrate: [300, 150, 300]
          });
          await webpush.sendNotification(subscription, payload);
          console.log(`Delayed background notification sent after ${delay}s!`);
        } catch (e: any) {
          console.error('Failed to send delayed push:', e?.message);
        }
      }, delay * 1000);

      return res.json({
        success: true,
        scheduled: true,
        delaySeconds: delay,
        message: `Notification scheduled in ${delay} seconds! Close this browser tab or lock your phone now to test background delivery.`
      });
    }

    try {
      const payload = JSON.stringify({
        title: quote.title,
        body: quote.body,
        url: '/',
        tag: 'instant-test-' + Date.now(),
        icon: '/pwa-192x192.png',
        badge: '/pwa-192x192.png',
        vibrate: [200, 100, 200]
      });

      await webpush.sendNotification(subscription, payload);
      res.json({ success: true, message: 'Test notification sent successfully!' });
    } catch (err: any) {
      console.error('Immediate push failure:', err);
      res.status(500).json({ error: 'Failed to send notification: ' + err?.message });
    }
  });

  app.get('/api/push/status', (req: Request, res: Response) => {
    res.json({
      vapidConfigured: Boolean(vapidKeys.publicKey),
      activeSubscribers: subscriptions.length,
      serverTime: new Date().toISOString()
    });
  });

  // Direct download route for index.zip
  const handleZipDownload = (req: Request, res: Response) => {
    const zipPath = path.resolve(__dirname, 'public', 'index.zip');
    if (fs.existsSync(zipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="index.zip"');
      return res.sendFile(zipPath);
    }
    return res.status(404).json({ error: 'index.zip not found' });
  };

  app.get('/api/download/index.zip', handleZipDownload);
  app.get('/index.zip', handleZipDownload);

  // Serve app via Vite in development, static in production
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Study Tracker server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server failed to start:', err);
  process.exit(1);
});
